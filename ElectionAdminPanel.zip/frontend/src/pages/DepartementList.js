// frontend/src/pages/DepartementList.js
import React from 'react';

const DepartementList = () => (
  <div className="p-4"><h1>Gestion des départements</h1></div>
);

export default DepartementList;
