// frontend/src/pages/PosteList.js
import React from 'react';

const PosteList = () => (
  <div className="p-4"><h1>Gestion des postes</h1></div>
);

export default PosteList;
