// frontend/src/pages/AffectationSuperviseur.js
import React from 'react';

const AffectationSuperviseur = () => (
  <div className="p-4"><h1>Attribuer une élection à un superviseur</h1></div>
);

export default AffectationSuperviseur;
