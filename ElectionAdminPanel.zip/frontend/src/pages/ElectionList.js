// frontend/src/pages/ElectionList.js
import React from 'react';

const ElectionList = () => (
  <div className="p-4"><h1>Liste des élections</h1></div>
);

export default ElectionList;
