// frontend/src/pages/UserList.js
import React from 'react';

const UserList = () => (
  <div className="p-4"><h1>Gestion des utilisateurs</h1></div>
);

export default UserList;
