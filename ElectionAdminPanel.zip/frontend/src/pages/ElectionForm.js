// frontend/src/pages/ElectionForm.js
import React from 'react';

const ElectionForm = () => (
  <div className="p-4"><h1>Créer une élection</h1></div>
);

export default ElectionForm;
