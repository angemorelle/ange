// backend/routes/postes.js
const express = require('express');
const router = express.Router();
// TODO: Import controller and define routes
router.get('/', ...); router.post('/', ...);
module.exports = router;
