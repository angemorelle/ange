
const express = require('express');
const cors = require('cors');
const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

app.use('/api/elections', require('./routes/elections'));
app.use('/api/utilisateurs', require('./routes/utilisateurs'));
app.use('/api/postes', require('./routes/postes'));
app.use('/api/departements', require('./routes/departements'));
app.use('/api/attributions', require('./routes/attributions'));

app.listen(port, () => {
  console.log(`Serveur backend sur http://localhost:${port}`);
});
