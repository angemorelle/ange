
Projet Admin Panel - Gestion Électorale

Contenu :
- frontend/src/pages/... : pages React pour l’interface d’administration
- backend/routes/... : routes Express pour gérer élections, utilisateurs, postes, départements, attributions
- backend/index.js : point d’entrée serveur Express

Instructions :
1. Créer un projet React dans le dossier frontend : npx create-react-app .
2. Ajouter une navigation entre les pages listées.
3. Compléter les contrôleurs et la base selon votre logique.
